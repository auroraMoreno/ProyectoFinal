﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SmithSwimmingApp.Migrations
{
    public partial class M3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "IdGrupo",
                table: "Cursos",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IdGrupo",
                table: "Cursos");
        }
    }
}
