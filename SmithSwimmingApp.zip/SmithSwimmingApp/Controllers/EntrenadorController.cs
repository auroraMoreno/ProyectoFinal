﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmithSwimmingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmithSwimmingApp.Controllers
{
    public class EntrenadorController:Controller
    {
        SmithSwimmingDbContext db;
        public EntrenadorController(SmithSwimmingDbContext db)
        {
            this.db = db;
        }

        public async Task<IActionResult> AllEntrenadores()
        {
            var entrenadores = await db.Entrenadores.ToListAsync();
            return View(entrenadores);
        }

        public IActionResult AddEntrenador()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddEntrenador(Entrenador entrenador)
        {
            db.Add(entrenador);
            await db.SaveChangesAsync();
            return RedirectToAction("AllEntrenadores");
        }
    }
}
