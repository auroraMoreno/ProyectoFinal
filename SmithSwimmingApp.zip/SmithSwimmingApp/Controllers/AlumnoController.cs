﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmithSwimmingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmithSwimmingApp.Controllers
{
    public class AlumnoController :Controller 
    {
        SmithSwimmingDbContext db;
        public AlumnoController(SmithSwimmingDbContext db)
        {
            this.db = db;
        }

        public async Task<IActionResult> AllAlumnos()
        {
            var alumnos = await db.Alumnos.ToListAsync();
            return View(alumnos);
        }

        public IActionResult AddAlumno()
        {
            //bool sexo = true;
            //ViewBag.Masculino = sexo;
            //ViewBag.Femenino = !sexo;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddAlumno(Alumno alumno)
        {
          
            db.Add(alumno);
            await db.SaveChangesAsync();
            return RedirectToAction("AllAlumnos");
        }
    }
}
