﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmithSwimmingApp.Models;
using SmithSwimmingApp.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace SmithSwimmingApp.Controllers
{
    public class GrupoController:Controller 
    {
        SmithSwimmingDbContext db;
        public GrupoController(SmithSwimmingDbContext db)
        {
            this.db = db;
        }
        public async Task<IActionResult> AllGrupos()
        {
            var grupos = await db.Grupos.Include(x => x.Curso).ToListAsync();
            return View(grupos);
        }
        public async Task<IActionResult> AddGrupo()
        {
            var cursoDisplay =
                await db.Cursos
                .Select(x => new
                {
                    Id = x.CursoId,
                    Value = x.NombreCurso
                }).ToListAsync();
            GrupoAddGrupoViewModel vm = new GrupoAddGrupoViewModel();
            vm.CursoList = new SelectList(cursoDisplay, "Id", "Value");
            return View(vm);
        }
        [HttpPost]
        public async Task<IActionResult> AddGrupo(GrupoAddGrupoViewModel vm)
        {

            var cursos = await db.Cursos.SingleOrDefaultAsync(x => x.CursoId == vm.Curso.CursoId);
            vm.Grupo.Curso = cursos;
            db.Add(vm.Grupo);
            await db.SaveChangesAsync();
            return RedirectToAction("AllGrupos");
        }

        public async Task<IActionResult> GrupoEspecifico(int id)
        {
            var cursos = await db.Cursos.Where(x => x.CursoId == id).ToListAsync();
            List<Grupo> grupos = new List<Grupo>();
            foreach(var x in cursos)
            {
                var grupo = await db.Grupos.SingleOrDefaultAsync(g => g.GrupoId==x.IdGrupo);
                grupos.Add(grupo);
            }
            ViewBag.Nombre = db.Cursos.Find(id).NombreCurso;
            return View(grupos);
        }
    }
}
