﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SmithSwimmingApp.Models;
using SmithSwimmingApp.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmithSwimmingApp.Controllers
{
    public class CursoController: Controller
    {
        SmithSwimmingDbContext db;
        public CursoController(SmithSwimmingDbContext db)
        {
            this.db = db;
        }
        public async Task<IActionResult> AllCursos()
        {
            var cursos = await db.Cursos.Include(x=>x.Entrenador).ToListAsync();
            return View(cursos);
        }

        public async Task<IActionResult> AddCurso()
        { 
            var entrenadorDisplay = await db.Entrenadores
                .Select(x => new
                {
                    Id = x.EntrenadorId,
                    Value = x.NombreEntrenador
                }).ToListAsync();
            CursoAddCursoViewModel vm = new CursoAddCursoViewModel();
            vm.EntrenadorList = new SelectList(entrenadorDisplay, "Id", "Value");

            return View(vm);
        }

        [HttpPost]
        public async Task<IActionResult> AddCurso(CursoAddCursoViewModel vm)
        {
            var entrenador = await db.Entrenadores.SingleOrDefaultAsync(x=>x.EntrenadorId==vm.Entrenador.EntrenadorId);
            vm.Curso.Entrenador = entrenador;
            db.Add(vm.Curso);
            await db.SaveChangesAsync();
            return RedirectToAction("AllCursos");
        }
    }
}
