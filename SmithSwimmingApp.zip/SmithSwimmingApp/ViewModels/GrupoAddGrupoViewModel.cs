﻿using Microsoft.AspNetCore.Mvc.Rendering;
using SmithSwimmingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmithSwimmingApp.ViewModels
{
    public class GrupoAddGrupoViewModel
    {
        public Curso Curso { get; set; }
        public SelectList CursoList { get; set; }

        public Grupo Grupo { get; set; }
    }
}
