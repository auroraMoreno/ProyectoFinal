﻿using Microsoft.AspNetCore.Mvc.Rendering;
using SmithSwimmingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmithSwimmingApp.ViewModels
{
    public class CursoAddCursoViewModel
    {
        public Curso Curso { get; set; }
        public Grupo Grupo { get; set; }
        public SelectList GrupoList { get; set; }
        public Entrenador Entrenador { get; set; }
        public SelectList EntrenadorList { get; set; }
    }
}
