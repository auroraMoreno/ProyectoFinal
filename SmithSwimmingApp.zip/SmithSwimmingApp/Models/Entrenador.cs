﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmithSwimmingApp.Models
{
    public class Entrenador
    {
        public int EntrenadorId { get; set; }
        public string NombreEntrenador { get; set; }
        public string NumeroTelefono { get; set; }
        public ICollection<Curso> Cursos { get; set; }
    }
}
