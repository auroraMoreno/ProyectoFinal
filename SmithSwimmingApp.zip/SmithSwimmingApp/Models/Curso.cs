﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmithSwimmingApp.Models
{
    public class Curso
    {
        public int CursoId { get; set; }
        public string NombreCurso { get; set; }
        public string NivelCurso { get; set; }
        public ICollection<Matricula> Matriculas{ get; set; }
        public ICollection<Grupo> Grupos { get; set; }
        public Entrenador Entrenador { get; set; }
        public int IdGrupo { get; set; }
    }
}
