﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmithSwimmingApp.Models
{
    public class Matricula
    {
        public int MatriculaId { get; set; }
        public int IdAlumno { get; set; }
        public Alumno Alumno { get; set; }
        public int IdCurso { get; set; }
        public Curso Curso { get; set; }
    }
}
