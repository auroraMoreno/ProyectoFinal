﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmithSwimmingApp.Models
{
    public class Grupo
    {
        public int GrupoId { get; set; }
        public string NombreGrupo { get; set; }
        public DateTime Fx_Inicio { get; set; }
        public DateTime Fx_Fin { get; set; }
        public int Plazas { get; set; }
        public int IdCurso { get; set; }
        public Curso Curso { get; set; }
    }
}
