﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmithSwimmingApp.Models
{
    public class SmithSwimmingDbContext: DbContext
    {
        public DbSet<Alumno> Alumnos { get; set; }
        public DbSet<Curso> Cursos { get; set; }
        public DbSet<Entrenador> Entrenadores { get; set; }
        public DbSet<Grupo> Grupos { get; set; }
        public DbSet<Matricula> Matriculas { get; set; }
        public SmithSwimmingDbContext(DbContextOptions<SmithSwimmingDbContext>options):base(options)
        {

        }
    }
}
