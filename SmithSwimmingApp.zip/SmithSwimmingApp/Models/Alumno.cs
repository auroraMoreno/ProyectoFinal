﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmithSwimmingApp.Models
{
    public class Alumno
    {
        public int AlumnoId { get; set; }
        public string NombreAlumno { get; set; }
        public string TelefonoAlumno { get; set; }
        public bool Sexo { get; set; }
        public DateTime Fx_Nacimiento_Alumno  { get; set; }
        public ICollection<Matricula> Matriculas { get; set; }
    }
}
